# Aturan ProGuard/R8 untuk build release (debug build tidak memakainya).
# Aplikasi ini tidak memakai refleksi atau library pihak ketiga,
# sehingga tidak ada aturan khusus yang diperlukan.
-keepattributes SourceFile,LineNumberTable
